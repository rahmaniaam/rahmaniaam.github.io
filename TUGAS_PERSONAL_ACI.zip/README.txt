{\rtf1\ansi\ansicpg1252\cocoartf1504\cocoasubrtf830
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0

\f0\fs24 \cf0 link tugas personal: rahmaniaam.github.io\
\
cara menjalankan di local server:\
- install scrollreveal.js (melalui npm)\
- buka index.html\
- enjoy:)\
\
library yang digunakan:\
- baffle.js\
- scrollreveal.js\
\
sumber gambar:\
- logo html5: https://www.w3.org/html/logo/downloads/HTML5_Logo_512.png\
\
- logo css3: http://www.idlewilddigital.com/sites/default/files/css3.png\
\
- logo javascript: https://upload.wikimedia.org/wikipedia/commons/thumb/9/99/Unofficial_JavaScript_logo_2.svg/2000px-Unofficial_JavaScript_logo_2.svg.png\
\
- logo python: http://www.pngall.com/wp-content/uploads/2016/05/Python-Logo-PNG-Image.png\
\
- logo java: https://lh3.googleusercontent.com/9Ki88wZ_tyxcrrGNWrY3DPU8fd3I0rISWjvs0y5FDYu-6UUy9bsDZOEogn9s7RsmqgY\
\
- logo django:  https://cdn.worldvectorlogo.com/logos/django.svg\
\
- mockup foye-foye: Hilya Auli Fesmia}